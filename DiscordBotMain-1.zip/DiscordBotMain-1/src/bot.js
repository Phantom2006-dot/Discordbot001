const { Client, GatewayIntentBits, Partials, EmbedBuilder, SlashCommandBuilder, REST, Routes, AttachmentBuilder } = require('discord.js');
const config = require('./config');
const { SocialScore, SocialMessageScore, SocialSubmission, Op } = require('./database');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Message, Partials.Reaction, Partials.User]
});

function getCurrentMonthKey() {
  const now = new Date();
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

function getCurrentDateKey() {
  const now = new Date();
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, '0');
  const day = String(now.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getMonthName() {
  const now = new Date();
  return now.toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' });
}

function isJudge(member) {
  return member.roles.cache.some(role => role.name === config.SOCIAL_ARMY_JUDGE_ROLE_NAME);
}

function isAdmin(member) {
  return member.roles.cache.some(role => role.name === config.ADMIN_ROLE_NAME);
}

function isOwner(userId, guild) {
  return guild.ownerId === userId;
}

async function checkDailySubmissionLimit(discordId) {
  const dateKey = getCurrentDateKey();
  const count = await SocialSubmission.count({
    where: { discordId, dateKey }
  });
  return { canSubmit: count < config.DAILY_SUBMISSION_LIMIT, currentCount: count };
}

const commands = [
  new SlashCommandBuilder()
    .setName('submit')
    .setDescription('Submit your content to Social Army for judging')
    .addStringOption(option =>
      option.setName('url')
        .setDescription('URL to your social media post (optional if attaching an image)')
        .setRequired(false))
    .addAttachmentOption(option =>
      option.setName('image')
        .setDescription('Attach an image/screenshot (optional if providing a URL)')
        .setRequired(false)),
  
  new SlashCommandBuilder()
    .setName('rankings')
    .setDescription('View the monthly Social Army rankings'),
  
  new SlashCommandBuilder()
    .setName('social-stats')
    .setDescription('View statistics for a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to check stats for (leave empty for yourself)')
        .setRequired(false)),
  
  new SlashCommandBuilder()
    .setName('social-config')
    .setDescription('View Social Army configuration'),
  
  new SlashCommandBuilder()
    .setName('social-reset')
    .setDescription('[ADMIN] Reset monthly scores and announce winners'),
  
  new SlashCommandBuilder()
    .setName('social-export')
    .setDescription('[ADMIN] Export top users')
    .addIntegerOption(option =>
      option.setName('limit')
        .setDescription('Number of top users to export (default: 10)')
        .setRequired(false))
];

client.once('ready', async () => {
  console.log(`${client.user.tag} has connected to Discord!`);
  console.log('Social Army - Reaction-Based Scoring System');
  console.log(`Monitoring channel ID: ${config.SOCIAL_ARMY_CHANNEL_ID}`);
  
  try {
    const rest = new REST({ version: '10' }).setToken(config.DISCORD_BOT_TOKEN);
    console.log('Started refreshing application (/) commands.');
    
    await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commands.map(cmd => cmd.toJSON()) }
    );
    
    console.log('Successfully reloaded application (/) commands.');
  } catch (error) {
    console.error('Failed to sync commands:', error);
  }
});

client.on('messageReactionAdd', async (reaction, user) => {
  if (user.bot) return;
  
  if (reaction.partial) {
    try {
      await reaction.fetch();
    } catch (error) {
      console.error('Error fetching reaction:', error);
      return;
    }
  }
  
  if (reaction.message.channel.id !== config.SOCIAL_ARMY_CHANNEL_ID) return;
  
  const emojiStr = reaction.emoji.name;
  
  if (!config.EMOJI_POINTS[emojiStr]) return;
  
  const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
  if (!member) return;
  
  if (!isJudge(member)) {
    try {
      await reaction.users.remove(user.id);
      console.log(`Removed unauthorized reaction ${emojiStr} from ${user.tag} (not a judge)`);
    } catch (error) {
      console.error('Error removing reaction:', error);
    }
    return;
  }
  
  if (config.OWNER_ONLY_EMOJIS.includes(emojiStr) && !isOwner(user.id, reaction.message.guild)) {
    try {
      await reaction.users.remove(user.id);
      console.log(`Removed owner-only reaction ${emojiStr} from ${user.tag}`);
    } catch (error) {
      console.error('Error removing reaction:', error);
    }
    return;
  }
  
  try {
    const submission = await SocialSubmission.findOne({
      where: { messageId: reaction.message.id.toString() }
    });
    
    let authorId;
    if (submission) {
      authorId = submission.discordId;
    } else if (!reaction.message.author.bot) {
      authorId = reaction.message.author.id;
    } else {
      return;
    }
    
    const points = config.EMOJI_POINTS[emojiStr];
    const monthKey = getCurrentMonthKey();
    const judgeId = user.id;
    const messageId = reaction.message.id;
    
    const existingScore = await SocialMessageScore.findOne({
      where: { messageId: messageId.toString(), judgeId, emoji: emojiStr }
    });
    
    if (existingScore) return;
    
    await SocialMessageScore.create({
      messageId: messageId.toString(),
      authorId,
      judgeId,
      emoji: emojiStr,
      points,
      monthKey
    });
    
    let userScore = await SocialScore.findOne({
      where: { discordId: authorId, monthKey }
    });
    
    if (!userScore) {
      let username;
      try {
        const submissionAuthor = await reaction.message.guild.members.fetch(authorId);
        username = submissionAuthor.user.tag;
      } catch {
        username = `User ${authorId}`;
      }
      
      userScore = await SocialScore.create({
        discordId: authorId,
        discordUsername: username,
        monthKey,
        points
      });
    } else {
      userScore.points += points;
      await userScore.save();
    }
    
    console.log(`Added ${points} points to user ${authorId} for ${emojiStr} from ${user.tag}`);
    
  } catch (error) {
    console.error('Error adding reaction score:', error);
  }
});

client.on('messageReactionRemove', async (reaction, user) => {
  if (user.bot) return;
  
  if (reaction.partial) {
    try {
      await reaction.fetch();
    } catch (error) {
      console.error('Error fetching reaction:', error);
      return;
    }
  }
  
  if (reaction.message.channel.id !== config.SOCIAL_ARMY_CHANNEL_ID) return;
  
  const emojiStr = reaction.emoji.name;
  
  if (!config.EMOJI_POINTS[emojiStr]) return;
  
  const judgeId = user.id;
  const messageId = reaction.message.id;
  
  try {
    const submission = await SocialSubmission.findOne({
      where: { messageId: messageId.toString() }
    });
    
    let authorId;
    if (submission) {
      authorId = submission.discordId;
    } else if (!reaction.message.author.bot) {
      authorId = reaction.message.author.id;
    } else {
      return;
    }
    
    const messageScore = await SocialMessageScore.findOne({
      where: { messageId: messageId.toString(), judgeId, emoji: emojiStr }
    });
    
    if (messageScore) {
      const points = messageScore.points;
      const scoreMonthKey = messageScore.monthKey;
      
      const userScore = await SocialScore.findOne({
        where: { discordId: authorId, monthKey: scoreMonthKey }
      });
      
      if (userScore) {
        userScore.points -= points;
        await userScore.save();
      }
      
      await messageScore.destroy();
      console.log(`Removed ${points} points from user ${authorId} for ${emojiStr} by ${user.tag}`);
    }
    
  } catch (error) {
    console.error('Error removing reaction score:', error);
  }
});

client.on('messageDelete', async (message) => {
  if (message.channel.id !== config.SOCIAL_ARMY_CHANNEL_ID) return;
  if (message.author && message.author.bot) return;
  
  try {
    const messageScores = await SocialMessageScore.findAll({
      where: { messageId: message.id.toString() }
    });
    
    if (messageScores.length === 0) return;
    
    let authorId = message.author ? message.author.id : null;
    
    if (!authorId) {
      const submission = await SocialSubmission.findOne({
        where: { messageId: message.id.toString() }
      });
      if (submission) {
        authorId = submission.discordId;
      } else if (messageScores.length > 0) {
        authorId = messageScores[0].authorId;
      }
    }
    
    if (!authorId) {
      await SocialMessageScore.destroy({
        where: { messageId: message.id.toString() }
      });
      console.log(`Removed orphaned message scores for message ${message.id} (no author found)`);
      return;
    }
    
    const pointsByMonth = {};
    for (const score of messageScores) {
      pointsByMonth[score.monthKey] = (pointsByMonth[score.monthKey] || 0) + score.points;
    }
    
    for (const [monthKey, totalPoints] of Object.entries(pointsByMonth)) {
      const userScore = await SocialScore.findOne({
        where: { discordId: authorId, monthKey }
      });
      
      if (userScore) {
        userScore.points -= totalPoints;
        await userScore.save();
      }
    }
    
    await SocialMessageScore.destroy({
      where: { messageId: message.id.toString() }
    });
    
    console.log(`Removed points from user ${authorId} across ${Object.keys(pointsByMonth).length} month(s) due to message deletion`);
    
  } catch (error) {
    console.error('Error handling message deletion:', error);
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  
  const { commandName } = interaction;
  
  if (commandName === 'submit') {
    await handleSubmit(interaction);
  } else if (commandName === 'rankings') {
    await handleRankings(interaction);
  } else if (commandName === 'social-stats') {
    await handleSocialStats(interaction);
  } else if (commandName === 'social-config') {
    await handleSocialConfig(interaction);
  } else if (commandName === 'social-reset') {
    await handleSocialReset(interaction);
  } else if (commandName === 'social-export') {
    await handleSocialExport(interaction);
  }
});

async function handleSubmit(interaction) {
  if (interaction.channel.id !== config.SOCIAL_ARMY_CHANNEL_ID) {
    await interaction.reply({
      content: `Please use the /submit command in <#${config.SOCIAL_ARMY_CHANNEL_ID}>`,
      ephemeral: true
    });
    return;
  }
  
  const discordId = interaction.user.id;
  const { canSubmit, currentCount } = await checkDailySubmissionLimit(discordId);
  
  if (!canSubmit) {
    await interaction.reply({
      content: `You've reached your daily submission limit (${config.DAILY_SUBMISSION_LIMIT} submissions per day). Try again tomorrow!`,
      ephemeral: true
    });
    return;
  }
  
  const url = interaction.options.getString('url');
  const image = interaction.options.getAttachment('image');
  
  if (!url && !image) {
    await interaction.reply({
      content: 'Please provide either a URL or attach an image with your submission.',
      ephemeral: true
    });
    return;
  }
  
  const submissionUrl = url || image.url;
  
  await interaction.deferReply();
  
  const embed = new EmbedBuilder()
    .setTitle('Social Army Submission')
    .setDescription(`Submitted by ${interaction.user}`)
    .setColor(0x3498db)
    .addFields({ name: 'Content', value: submissionUrl, inline: false })
    .setFooter({ text: `Submission ${currentCount + 1}/${config.DAILY_SUBMISSION_LIMIT} today` })
    .setTimestamp();
  
  if (image && image.contentType && image.contentType.startsWith('image/')) {
    embed.setImage(image.url);
  }
  
  const submissionMessage = await interaction.followUp({ embeds: [embed], fetchReply: true });
  
  for (const emoji of Object.keys(config.EMOJI_POINTS)) {
    try {
      await submissionMessage.react(emoji);
    } catch (error) {
      console.log(`Failed to add emoji ${emoji}:`, error.message);
    }
  }
  
  if (url) {
    try {
      await interaction.channel.send(url);
    } catch (error) {
      console.log('Failed to send link message:', error.message);
    }
  }
  
  try {
    const dateKey = getCurrentDateKey();
    await SocialSubmission.create({
      discordId,
      dateKey,
      messageId: submissionMessage.id.toString(),
      submissionUrl
    });
    console.log(`Submission created for ${interaction.user.tag} - Message ID: ${submissionMessage.id}`);
  } catch (error) {
    console.error('Error saving submission:', error);
  }
}

async function handleRankings(interaction) {
  await interaction.deferReply();
  
  const monthKey = getCurrentMonthKey();
  
  try {
    const topUsers = await SocialScore.findAll({
      where: { monthKey },
      order: [['points', 'DESC']],
      limit: config.LEADERBOARD_SIZE
    });
    
    if (topUsers.length === 0) {
      await interaction.followUp('No scores yet this month! Start posting in the Social Army channel!');
      return;
    }
    
    const monthName = getMonthName();
    const embed = new EmbedBuilder()
      .setTitle(`Social Army Rankings - ${monthName}`)
      .setDescription('Top contributors this month:')
      .setColor(0xf1c40f);
    
    const medals = ['🥇', '🥈', '🥉'];
    for (let idx = 0; idx < topUsers.length; idx++) {
      const user = topUsers[idx];
      const medal = idx < 3 ? medals[idx] : `#${idx + 1}`;
      
      let username;
      try {
        const member = await interaction.guild.members.fetch(user.discordId);
        username = member.displayName;
      } catch {
        username = user.discordUsername || `User ${user.discordId}`;
      }
      
      embed.addFields({ name: `${medal} ${username}`, value: `**${user.points}** points`, inline: false });
    }
    
    await interaction.followUp({ embeds: [embed] });
    
  } catch (error) {
    console.error('Error fetching rankings:', error);
    await interaction.followUp(`Error: ${error.message}`);
  }
}

async function handleSocialStats(interaction) {
  await interaction.deferReply();
  
  const targetUser = interaction.options.getUser('user') || interaction.user;
  const monthKey = getCurrentMonthKey();
  
  try {
    const userScore = await SocialScore.findOne({
      where: { discordId: targetUser.id, monthKey }
    });
    
    if (!userScore || userScore.points === 0) {
      const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
      const displayName = member ? member.displayName : targetUser.tag;
      await interaction.followUp(`${displayName} has no points this month yet!`);
      return;
    }
    
    const rank = await SocialScore.count({
      where: {
        monthKey,
        points: { [Op.gt]: userScore.points }
      }
    }) + 1;
    
    const messageScores = await SocialMessageScore.findAll({
      where: { authorId: targetUser.id, monthKey }
    });
    
    const emojiBreakdown = {};
    for (const score of messageScores) {
      emojiBreakdown[score.emoji] = (emojiBreakdown[score.emoji] || 0) + score.points;
    }
    
    const monthName = getMonthName();
    const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
    const displayName = member ? member.displayName : targetUser.tag;
    
    const embed = new EmbedBuilder()
      .setTitle(`Stats for ${displayName}`)
      .setDescription(`Month: ${monthName}`)
      .setColor(0x3498db)
      .addFields(
        { name: 'Total Points', value: `**${userScore.points}**`, inline: true },
        { name: 'Rank', value: `**#${rank}**`, inline: true },
        { name: 'Reactions Received', value: `**${messageScores.length}**`, inline: true }
      );
    
    if (Object.keys(emojiBreakdown).length > 0) {
      const breakdownText = Object.entries(emojiBreakdown)
        .sort((a, b) => b[1] - a[1])
        .map(([emoji, pts]) => `${emoji}: ${pts} pts`)
        .join('\n');
      embed.addFields({ name: 'Points by Category', value: breakdownText, inline: false });
    }
    
    await interaction.followUp({ embeds: [embed] });
    
  } catch (error) {
    console.error('Error fetching social stats:', error);
    await interaction.followUp(`Error: ${error.message}`);
  }
}

async function handleSocialConfig(interaction) {
  await interaction.deferReply({ ephemeral: true });
  
  const embed = new EmbedBuilder()
    .setTitle('Social Army Configuration')
    .setColor(0x3498db);
  
  const channel = client.channels.cache.get(config.SOCIAL_ARMY_CHANNEL_ID);
  const channelName = channel ? `#${channel.name}` : `ID: ${config.SOCIAL_ARMY_CHANNEL_ID}`;
  
  embed.addFields(
    { name: 'Social Army Channel', value: channelName, inline: false },
    { name: 'Judge Role', value: config.SOCIAL_ARMY_JUDGE_ROLE_NAME, inline: true },
    { name: 'Elite Role', value: config.SOCIAL_ARMY_ELITE_ROLE_NAME, inline: true },
    { name: 'Leaderboard Size', value: String(config.LEADERBOARD_SIZE), inline: true },
    { name: 'Effort', value: '✍️ (1pt), 🎨 (3pt), 🎬 (5pt), 🎞️ (8pt)', inline: false },
    { name: 'Creativity', value: '💡 (2pt), 🤯 (4pt)', inline: false },
    { name: 'Reach', value: '📊 (2pt), 🔥 (4pt), 🚀 (8pt)', inline: false },
    { name: 'Consistency', value: '🧡 (2pt), 💪 (3pt)', inline: false },
    { name: 'Bonus', value: '🏅 (5pt), 👑 (10pt - Owner only)', inline: false }
  );
  
  await interaction.followUp({ embeds: [embed], ephemeral: true });
}

async function handleSocialReset(interaction) {
  if (!isAdmin(interaction.member)) {
    await interaction.reply({ content: "You don't have permission to use this command!", ephemeral: true });
    return;
  }
  
  await interaction.deferReply();
  
  const monthKey = getCurrentMonthKey();
  const monthName = getMonthName();
  
  try {
    const topUsers = await SocialScore.findAll({
      where: { monthKey },
      order: [['points', 'DESC']],
      limit: 3
    });
    
    let winnersAnnounced = false;
    if (topUsers.length > 0) {
      const embed = new EmbedBuilder()
        .setTitle(`${monthName} Winners!`)
        .setDescription('Congratulations to our top Social Army contributors!')
        .setColor(0xf1c40f);
      
      const medals = ['🥇', '🥈', '🥉'];
      for (let idx = 0; idx < topUsers.length; idx++) {
        const user = topUsers[idx];
        let username;
        try {
          const member = await interaction.guild.members.fetch(user.discordId);
          username = member.displayName;
        } catch {
          username = user.discordUsername || `User ${user.discordId}`;
        }
        
        embed.addFields({ name: `${medals[idx]} ${username}`, value: `**${user.points}** points`, inline: false });
      }
      
      const channel = client.channels.cache.get(config.SOCIAL_ARMY_CHANNEL_ID);
      if (channel) {
        await channel.send({ embeds: [embed] });
        winnersAnnounced = true;
      }
    }
    
    const scoreCount = await SocialScore.destroy({ where: { monthKey } });
    const messageScoreCount = await SocialMessageScore.destroy({ where: { monthKey } });
    
    let message = 'Monthly reset complete! ';
    if (winnersAnnounced) {
      message += `Winners announced in <#${config.SOCIAL_ARMY_CHANNEL_ID}>. `;
    }
    message += `Deleted ${scoreCount} user scores and ${messageScoreCount} message scores.`;
    
    await interaction.followUp(message);
    
  } catch (error) {
    console.error('Error during social reset:', error);
    await interaction.followUp(`Error: ${error.message}`);
  }
}

async function handleSocialExport(interaction) {
  if (!isAdmin(interaction.member)) {
    await interaction.reply({ content: "You don't have permission to use this command!", ephemeral: true });
    return;
  }
  
  await interaction.deferReply({ ephemeral: true });
  
  const limit = interaction.options.getInteger('limit') || 10;
  const monthKey = getCurrentMonthKey();
  
  try {
    const topUsers = await SocialScore.findAll({
      where: { monthKey },
      order: [['points', 'DESC']],
      limit
    });
    
    if (topUsers.length === 0) {
      await interaction.followUp({ content: 'No scores to export!', ephemeral: true });
      return;
    }
    
    let exportText = `Social Army Leaderboard Export - ${getMonthName()}\n`;
    exportText += '='.repeat(50) + '\n\n';
    
    for (let idx = 0; idx < topUsers.length; idx++) {
      const user = topUsers[idx];
      let username;
      try {
        const member = await interaction.guild.members.fetch(user.discordId);
        username = member.displayName;
      } catch {
        username = user.discordUsername || `User ${user.discordId}`;
      }
      
      exportText += `${idx + 1}. ${username} - ${user.points} points\n`;
    }
    
    const buffer = Buffer.from(exportText, 'utf-8');
    const attachment = new AttachmentBuilder(buffer, { name: 'social_army_export.txt' });
    
    await interaction.followUp({
      content: 'Export complete!',
      files: [attachment],
      ephemeral: true
    });
    
  } catch (error) {
    console.error('Error during export:', error);
    await interaction.followUp({ content: `Error: ${error.message}`, ephemeral: true });
  }
}

module.exports = { client };
