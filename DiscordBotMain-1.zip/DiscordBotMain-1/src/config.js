require('dotenv').config();

module.exports = {
  DISCORD_BOT_TOKEN: process.env.DISCORD_BOT_TOKEN,
  DISCORD_GUILD_ID: process.env.DISCORD_GUILD_ID || '0',
  ADMIN_ROLE_NAME: process.env.ADMIN_ROLE_NAME || 'Admin',
  
  DATABASE_URL: process.env.DATABASE_URL,
  
  SOCIAL_ARMY_CHANNEL_ID: process.env.SOCIAL_ARMY_CHANNEL_ID || '0',
  SOCIAL_ARMY_JUDGE_ROLE_NAME: process.env.SOCIAL_ARMY_JUDGE_ROLE_NAME || 'Social Army Judge',
  SOCIAL_ARMY_ELITE_ROLE_NAME: process.env.SOCIAL_ARMY_ELITE_ROLE_NAME || 'Social Army Elite',
  LEADERBOARD_SIZE: parseInt(process.env.LEADERBOARD_SIZE || '10', 10),
  DAILY_SUBMISSION_LIMIT: parseInt(process.env.DAILY_SUBMISSION_LIMIT || '5', 10),
  
  EMOJI_POINTS: {
    '✍️': 1,
    '🎨': 3,
    '🎬': 5,
    '🎞️': 8,
    '💡': 2,
    '🤯': 4,
    '📊': 2,
    '🔥': 4,
    '🚀': 8,
    '🧡': 2,
    '💪': 3,
    '🏅': 5,
    '👑': 10
  },
  
  OWNER_ONLY_EMOJIS: ['🏅', '👑']
};
