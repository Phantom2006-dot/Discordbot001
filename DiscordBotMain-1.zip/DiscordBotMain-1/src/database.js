const { Sequelize, DataTypes, Op } = require('sequelize');
const config = require('./config');

const sequelize = new Sequelize(config.DATABASE_URL, {
  dialect: 'postgres',
  logging: false,
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false
    }
  }
});

const SocialScore = sequelize.define('SocialScore', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  discordId: {
    type: DataTypes.STRING(50),
    allowNull: false,
    field: 'discord_id'
  },
  discordUsername: {
    type: DataTypes.STRING(100),
    field: 'discord_username'
  },
  monthKey: {
    type: DataTypes.STRING(7),
    allowNull: false,
    field: 'month_key'
  },
  points: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
}, {
  tableName: 'social_scores',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  indexes: [
    { fields: ['discord_id'] },
    { fields: ['month_key'] },
    { fields: ['discord_id', 'month_key'], name: 'idx_user_month' }
  ]
});

const SocialMessageScore = sequelize.define('SocialMessageScore', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  messageId: {
    type: DataTypes.BIGINT,
    allowNull: false,
    field: 'message_id'
  },
  authorId: {
    type: DataTypes.STRING(50),
    allowNull: false,
    field: 'author_id'
  },
  judgeId: {
    type: DataTypes.STRING(50),
    allowNull: false,
    field: 'judge_id'
  },
  emoji: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  points: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  monthKey: {
    type: DataTypes.STRING(7),
    allowNull: false,
    field: 'month_key'
  }
}, {
  tableName: 'social_message_scores',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  indexes: [
    { fields: ['message_id'] },
    { fields: ['author_id'] },
    { fields: ['month_key'] },
    { fields: ['message_id', 'judge_id', 'emoji'], name: 'idx_message_judge_emoji' }
  ]
});

const SocialSubmission = sequelize.define('SocialSubmission', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  discordId: {
    type: DataTypes.STRING(50),
    allowNull: false,
    field: 'discord_id'
  },
  dateKey: {
    type: DataTypes.STRING(10),
    allowNull: false,
    field: 'date_key'
  },
  messageId: {
    type: DataTypes.BIGINT,
    allowNull: false,
    field: 'message_id'
  },
  submissionUrl: {
    type: DataTypes.STRING(500),
    field: 'submission_url'
  }
}, {
  tableName: 'social_submissions',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  indexes: [
    { fields: ['discord_id'] },
    { fields: ['date_key'] },
    { fields: ['discord_id', 'date_key'], name: 'idx_user_date' }
  ]
});

async function initDb() {
  try {
    await sequelize.authenticate();
    console.log('Database connection established successfully.');
    await sequelize.sync();
    console.log('Database schema synchronized.');
    return true;
  } catch (error) {
    console.error('Unable to connect to the database:', error);
    return false;
  }
}

module.exports = {
  sequelize,
  SocialScore,
  SocialMessageScore,
  SocialSubmission,
  initDb,
  Op
};
