const { initDb } = require('./src/database');
const { client } = require('./src/bot');
const config = require('./src/config');

async function main() {
  console.log('='.repeat(60));
  console.log('Social Army Discord Bot - Reaction-Based Scoring');
  console.log('='.repeat(60));
  
  console.log('\nInitializing database...');
  const dbConnected = await initDb();
  
  if (!dbConnected) {
    console.error('Failed to connect to database. Exiting...');
    process.exit(1);
  }
  console.log('Database initialized!');
  
  console.log('\nStarting Discord bot...');
  
  if (!config.DISCORD_BOT_TOKEN) {
    console.error('ERROR: DISCORD_BOT_TOKEN is not set!');
    console.log('Please set the DISCORD_BOT_TOKEN environment variable.');
    process.exit(1);
  }
  
  try {
    await client.login(config.DISCORD_BOT_TOKEN);
  } catch (error) {
    console.error('Failed to login to Discord:', error.message);
    process.exit(1);
  }
}

process.on('SIGINT', () => {
  console.log('\nShutting down...');
  client.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\nShutting down...');
  client.destroy();
  process.exit(0);
});

main();
