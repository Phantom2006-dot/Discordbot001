# Social Army Discord Bot

## Overview
A Discord bot with a reaction-based scoring system for the "Social Army" community. Users submit content, judges react with emoji reactions, and points are tracked monthly with leaderboards.

## Project Structure
```
.
├── index.js           # Entry point - initializes database and starts bot
├── src/
│   ├── config.js      # Configuration with environment variables and emoji points
│   ├── database.js    # Sequelize models (SocialScore, SocialMessageScore, SocialSubmission)
│   └── bot.js         # Main bot file with commands and event handlers
├── package.json
└── .gitignore
```

## Features
- **Reaction-Based Scoring**: Judges react to submissions with emojis, each worth different points
- **Monthly Leaderboards**: `/rankings` command shows top contributors
- **Submission System**: `/submit` command with daily limits (5/day)
- **Role Permissions**: Only users with "Social Army Judge" role can add scoring reactions
- **Owner-Only Emojis**: 🏅 (5pt) and 👑 (10pt) reserved for server owner
- **Stats Tracking**: `/social-stats` shows user statistics
- **Admin Commands**: `/social-reset` and `/social-export` for administrators

## Emoji Point Values
| Category | Emojis |
|----------|--------|
| Effort | ✍️ (1pt), 🎨 (3pt), 🎬 (5pt), 🎞️ (8pt) |
| Creativity | 💡 (2pt), 🤯 (4pt) |
| Reach | 📊 (2pt), 🔥 (4pt), 🚀 (8pt) |
| Consistency | 🧡 (2pt), 💪 (3pt) |
| Bonus | 🏅 (5pt), 👑 (10pt - Owner only) |

## Slash Commands
- `/submit` - Submit content with URL or image for judging
- `/rankings` - View monthly leaderboard
- `/social-stats` - View user statistics
- `/social-config` - View bot configuration
- `/social-reset` - [ADMIN] Reset monthly scores and announce winners
- `/social-export` - [ADMIN] Export top users to file

## Required Environment Variables
- `DISCORD_BOT_TOKEN` - Discord bot token (required)
- `DATABASE_URL` - PostgreSQL connection string (auto-configured by Replit)
- `SOCIAL_ARMY_CHANNEL_ID` - Channel ID for submissions (required)
- `SOCIAL_ARMY_JUDGE_ROLE_NAME` - Role name for judges (default: "Social Army Judge")
- `SOCIAL_ARMY_ELITE_ROLE_NAME` - Role name for elite members (default: "Social Army Elite")
- `ADMIN_ROLE_NAME` - Role name for admins (default: "Admin")
- `LEADERBOARD_SIZE` - Number of users to show in rankings (default: 10)
- `DAILY_SUBMISSION_LIMIT` - Max submissions per day (default: 5)

## Database Tables
- `social_scores` - Monthly points per user
- `social_message_scores` - Individual reaction tracking
- `social_submissions` - Daily submission tracking

## Recent Changes
- November 2025: Initial JavaScript port from Python version
  - Migrated all features from Python Discord bot
  - Using Sequelize ORM with PostgreSQL
  - Discord.js v14 with slash commands
